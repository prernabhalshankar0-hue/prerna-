# Python Program to Check if a Number is Positive, Negative or 0 - Prerna Bhalshankar
n = float(input())
if n>0: print("Positive")
elif n<0: print("Negative")
else: print("Zero")