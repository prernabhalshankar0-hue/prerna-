# Python Program to Display Powers of 2 Using Anonymous Function - Prerna Bhalshankar
n = int(input())
powers = list(map(lambda x: 2**x, range(n)))
print(powers)