# Python Program to Display Calendar - Prerna Bhalshankar
import calendar
y = int(input())
m = int(input())
print(calendar.month(y,m))