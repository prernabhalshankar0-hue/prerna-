# Python Program to Print the Fibonacci sequence - Prerna Bhalshankar
n = int(input())
a,b=0,1
for i in range(n):
    print(a,end=" ")
    a,b=b,a+b