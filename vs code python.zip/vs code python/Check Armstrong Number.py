# Python Program to Check Armstrong Number - Prerna Bhalshankar
n = int(input())
s = sum(int(d)**len(str(n)) for d in str(n))
print("Armstrong" if s==n else "Not Armstrong")