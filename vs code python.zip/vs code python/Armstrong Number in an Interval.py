# Python Program to Find Armstrong Number in an Interval - Prerna Bhalshankar
l,u = map(int,input().split())
for n in range(l,u+1):
    if n==sum(int(d)**len(str(n)) for d in str(n)):
        print(n,end=" ")