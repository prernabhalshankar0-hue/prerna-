# Python Program to Add Two Matrices - Prerna Bhalshankar
a = eval(input())
b = eval(input())
r = [[a[i][j]+b[i][j] for j in range(len(a[0]))] for i in range(len(a))]
print(r)