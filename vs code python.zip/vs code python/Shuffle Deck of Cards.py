# Python Program to Shuffle Deck of Cards - Prerna Bhalshankar
import random
deck = [(v,s) for v in range(1,14) for s in ['H','D','C','S']]
random.shuffle(deck)
print(deck)