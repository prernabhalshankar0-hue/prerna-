# Python Program to Access Index of a List Using for Loop - Prerna Bhalshankar
l = list(map(int,input().split()))
for i in range(len(l)):
    print(i,l[i])