# Python Program to Find HCF or GCD - Prerna Bhalshankar
import math
a,b = map(int,input().split())
print(math.gcd(a,b))