# Python Program to Swap Two Variables - Prerna Bhalshankar
a = input()
b = input()
a, b = b, a
print(a, b)