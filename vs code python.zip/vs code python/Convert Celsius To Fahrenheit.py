# Python Program to Convert Celsius To Fahrenheit - Prerna Bhalshankar
c = float(input())
print((c*9/5)+32)