# Python Program to Remove Punctuations From a String - Prerna Bhalshankar
import string
s = input()
print("".join(c for c in s if c not in string.punctuation))