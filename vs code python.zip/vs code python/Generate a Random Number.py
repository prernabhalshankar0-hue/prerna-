# Python Program to Generate a Random Number - Prerna Bhalshankar
import random
print(random.randint(1,100))