# Python Program to Print ABCDEFGHIJKLMNO in Triangle Pattern
# Name: prerna bhalshankar

n = 5
ch = 65   # ASCII of 'A'

for i in range(1, n+1):
    for j in range(i):
        print(chr(ch), end=" ")
        ch += 1
    print()