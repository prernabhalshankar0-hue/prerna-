# Python Program to Find the Sum of Natural Numbers - Prerna Bhalshankar
n = int(input())
print(n*(n+1)//2)