# Python Program to Multiply Two Matrices - Prerna Bhalshankar
a = eval(input())
b = eval(input())
r = [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
print(r)