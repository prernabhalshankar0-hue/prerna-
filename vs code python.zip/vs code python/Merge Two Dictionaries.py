# Python Program to Merge Two Dictionaries - Prerna Bhalshankar
d1 = eval(input())
d2 = eval(input())
d1.update(d2)
print(d1)