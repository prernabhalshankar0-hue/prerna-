# Python Program to Find Numbers Divisible by Another Number - Prerna Bhalshankar
l = list(map(int,input().split()))
n = int(input())
print([i for i in l if i%n==0])