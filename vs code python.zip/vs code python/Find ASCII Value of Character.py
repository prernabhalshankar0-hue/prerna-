# Python Program to Find ASCII Value of Character - Prerna Bhalshankar
c = input()
print(ord(c))