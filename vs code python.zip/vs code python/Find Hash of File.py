# Python Program to Find Hash of File - Prerna Bhalshankar
import hashlib
f = open(input(),"rb").read()
print(hashlib.md5(f).hexdigest())