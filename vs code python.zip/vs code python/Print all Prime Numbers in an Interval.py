# Python Program to Print all Prime Numbers in an Interval - Prerna Bhalshankar
l,u = map(int,input().split())
for n in range(l,u+1):
    if n>1:
        for i in range(2,n):
            if n%i==0:
                break
        else:
            print(n,end=" ")