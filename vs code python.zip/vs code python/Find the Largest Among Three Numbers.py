# Python Program to Find the Largest Among Three Numbers - Prerna Bhalshankar
a,b,c = map(int,input().split())
print(max(a,b,c))