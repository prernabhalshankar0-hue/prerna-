# Python Program to Check if a Number is Odd or Even - Prerna Bhalshankar
n = int(input())
print("Even" if n%2==0 else "Odd")