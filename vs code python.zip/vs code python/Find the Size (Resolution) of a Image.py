# Python Program to Find the Size (Resolution) of a Image - Prerna Bhalshankar
from PIL import Image
img = Image.open(input())
print(img.size)