# Python Program to Convert Kilometers to Miles - Prerna Bhalshankar
km = float(input())
print(km*0.621371)