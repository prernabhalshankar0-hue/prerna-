# Python Program to Find the Factorial of a Number - Prerna Bhalshankar
n = int(input())
f=1
for i in range(1,n+1):
    f*=i
print(f)