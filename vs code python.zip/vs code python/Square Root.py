# Python Program to Find the Square Root - Prerna Bhalshankar
import math
n = float(input())
print(math.sqrt(n))