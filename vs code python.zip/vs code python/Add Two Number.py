# Python Program to Add Two Numbers - Prerna Bhalshankar
a = float(input())
b = float(input())
print(a + b)