# Python Program to Check Whether a String is Palindrome or Not - Prerna Bhalshankar
s = input()
print("Palindrome" if s==s[::-1] else "Not Palindrome")