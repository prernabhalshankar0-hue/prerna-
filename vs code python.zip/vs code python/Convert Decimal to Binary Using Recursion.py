# Python Program to Convert Decimal to Binary Using Recursion - Prerna Bhalshankar
def b(n):
    if n>1: b(n//2)
    print(n%2,end="")
b(int(input()))