# Python Program to Merge Mails - Prerna Bhalshankar
a = input().split(',')
b = input().split(',')
print(a+b)