# Python Program to Find Sum of Natural Numbers Using Recursion - Prerna Bhalshankar
def s(n):
    return n if n==1 else n+s(n-1)
print(s(int(input())))