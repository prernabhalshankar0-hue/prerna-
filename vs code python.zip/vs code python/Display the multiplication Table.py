# Python Program to Display the multiplication Table - Prerna Bhalshankar
n = int(input())
for i in range(1,11):
    print(n*i)