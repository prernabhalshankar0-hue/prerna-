# Python Program to Sort Words in Alphabetic Order - Prerna Bhalshankar
s = input().split()
s.sort()
print(" ".join(s))