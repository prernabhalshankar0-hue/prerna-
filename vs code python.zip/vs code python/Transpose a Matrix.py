# Python Program to Transpose a Matrix - Prerna Bhalshankar
m = eval(input())
print(list(map(list, zip(*m))))