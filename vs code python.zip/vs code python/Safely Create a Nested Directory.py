# Python Program to Safely Create a Nested Directory - Prerna Bhalshankar
import os
os.makedirs(input(), exist_ok=True)