# Python Program to Illustrate Different Set Operations - Prerna Bhalshankar
a = set(map(int,input().split()))
b = set(map(int,input().split()))
print(a|b)
print(a&b)
print(a-b)