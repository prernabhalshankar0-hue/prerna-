# Python Program to Print Star Triangle Pattern
# Name: prerna bhalshankar

n = 5

for i in range(1, n+1):
    for j in range(i):
        print("1", end=" ")
    print()