# Python Program to Display Fibonacci Sequence Using Recursion - Prerna Bhalshankar
def f(n):
    return n if n<=1 else f(n-1)+f(n-2)
n=int(input())
for i in range(n):
    print(f(i),end=" ")