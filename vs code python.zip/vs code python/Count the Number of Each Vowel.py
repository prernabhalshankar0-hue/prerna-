# Python Program to Count the Number of Each Vowel - Prerna Bhalshankar
s = input().lower()
for v in "aeiou":
    print(v, s.count(v))