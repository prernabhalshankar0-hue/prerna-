# Python Program to Create Pyramid Patterns - Prerna Bhalshankar
n = int(input())
for i in range(1,n+1):
    print(" "*(n-i)+"*"*(2*i-1))