# Python Program to Find the Factors of a Number - Prerna Bhalshankar
n = int(input())
for i in range(1,n+1):
    if n%i==0:
        print(i,end=" ")