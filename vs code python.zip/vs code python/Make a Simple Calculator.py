# Python Program to Make a Simple Calculator - Prerna Bhalshankar
a = float(input())
b = float(input())
op = input()
if op=='+': print(a+b)
elif op=='-': print(a-b)
elif op=='*': print(a*b)
elif op=='/': print(a/b)