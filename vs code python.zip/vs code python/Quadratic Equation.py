# Python Program to Solve Quadratic Equation - Prerna Bhalshankar
import cmath
a = float(input())
b = float(input())
c = float(input())
d = (b**2) - (4*a*c)
x1 = (-b+cmath.sqrt(d))/(2*a)
x2 = (-b-cmath.sqrt(d))/(2*a)
print(x1, x2)