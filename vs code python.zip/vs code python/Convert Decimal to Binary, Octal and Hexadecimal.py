# Python Program to Convert Decimal to Binary, Octal and Hexadecimal - Prerna Bhalshankar
n = int(input())
print(bin(n))
print(oct(n))
print(hex(n))