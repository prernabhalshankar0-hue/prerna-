# Python Program to Print 1 to 10 in Triangle Pattern
# Name: prerna bhalshankar

n = 4
num = 1

for i in range(1, n+1):
    for j in range(i):
        print(num, end=" ")
        num += 1
    print()